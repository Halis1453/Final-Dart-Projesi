import 'package:flutter/material.dart';

import '../services/api.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  register() {}

  bool loading = false;

  var programs = [];

  loadPrograms() async {
      API api = API();
      var response = await api.getPrograms();

      if(response is Exception) {
        // TODO mesaj yaz tekrar dene
      }
      else {
        print(response);
        setState(() {
          programs = response["data"];

        });
      }

      setState(() {
        loading = false;
      });
    }
    @override
    void initState() {
      super.initState();
      loadPrograms();
    }

  @override
  Widget build(BuildContext context) {
    

    return Scaffold(
      appBar: AppBar(
        title: Text("Kayit"),
      ),
      body: SafeArea(
        child: loading ? LinearProgressIndicator() : Column(
          children: [
            Text("Name:"),
            TextField(),
            Text("Email:"),
            TextField(),
            Text("Password:"),
            TextField(),
            Text("Program:"),
            Divider(),
            ElevatedButton(onPressed: register, child: Text("Giriş Yap")),
            Divider(),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pushNamed("/register"), 
              child: Text("Giriş Yapmak için Tıklayınız"))
          ],
        ),
      ),
    );
  }
}