import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/storage.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  Map<String, dynamic> user = {
    "name": "",
    "id": -1,
    "phone": "",
    "email": "",
  };
  checkLogin() async {
    
    Storage storage = Storage();

    final user = await storage.loadUser();

    if(user != null) {
      setState(() {
        this.user = user;
      });
    }
    else {
      Navigator.pushReplacementNamed(context, "/login");
    }
  }

  instagram() {
    final Uri uri = Uri.parse("https//instagram.com/keyvan_arasteh");
    launchUrl(uri);
  }

  linkedin() {
    final Uri uri = Uri.parse("https//linkedin.com/in/keyvanarasteh");
    launchUrl(uri);
  }

  call() {
    final Uri uri = Uri.parse("tell:+905528609999");
    launchUrl(uri);
  }

  whatsapp() {
    final Uri uri = Uri.parse("https://wa.me/+905528609999?text=metin");
    launchUrl(uri);
  }

  sms() {
    final Uri uri = Uri.parse("sms:+905528609999");
    launchUrl(uri);
  }

  mail() {
    final Uri uri = Uri.parse("mailto:keyvan.arasteh@live.com?subject=Destek Talepi&body=Merhaba Uygulamayla ilgili problemim var");
    launchUrl(uri);
  }

  @override
  void initState() {
    super.initState();
    checkLogin();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home")),
      body: SafeArea(
        child:  Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Name: ${user["name"]}"),
              Text("Email: ${user["email"]}"),
              Text("Phone: ${user["phone"]}"),
              Text("id: ${user["id"]}"),
          
              ElevatedButton(
                onPressed: () async {
                  Storage storage = Storage();
                  await storage.clearUser();
                  Navigator.of(context).pushReplacementNamed("/login");
                },
                child: Text("Logout"),
              ),
              SizedBox(height: 30),
              Row(
                children: [
                  InkWell(
                    onTap: instagram,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: SvgPicture.asset(
                        "assets/icons/instagram.svg",
                        height: 32,
                        colorFilter: ColorFilter.mode(Colors.blue, BlendMode.srcIn),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: linkedin,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: SvgPicture.asset("assets/icons/linkedin.svg",
                      height: 32,
                      colorFilter: ColorFilter.mode(Colors.blue, BlendMode.srcIn),
                      ),
                    ),
                  ),
                  InkWell(
                    onTap: call,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.phone)
                    ),
                  ),
                  InkWell(
                    onTap: sms,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.message)
                    ),
                  ),
                  InkWell(
                    onTap: mail,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.email)
                    ),
                  ),
                  InkWell(
                    onTap: whatsapp,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Icon(Icons.share)
                    ),
                  ),
                ],
              ),
            ],
          ),
        ), 
      ),
    );
  }
}