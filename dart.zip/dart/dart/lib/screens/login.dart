// ignore: unused_import
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../core/storage.dart';
import '../services/api.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  bool loading = false;
  var emailController = TextEditingController();
  var passswordController = TextEditingController();


  login() async{
    setState(() {
      loading = true;
    }); 

    API api = API();

    final response = await api.login(
      username: emailController.text, 
      password: passswordController.text,
    );

    if(response is Exception) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Girdiğiniz bilgiler yanliş"),
        backgroundColor: Colors.orange,    
      ));
    } else {
      Storage storage = Storage();
      
      await storage.saveUser(
        id: response["data"]["user"]["id"],
        name: response["data"]["user"]["name"],
        email: response["data"]["user"]["email"],
        phone: response["data"]["user"]["phone_number"]);
      
      await storage.saveToken(response["data"]["token"]);

      Navigator.of(context).pushReplacementNamed("/home"); 
    }
    


    setState(() {
      loading = false;
    });      
  }
   

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Giriş Yapınız"),
      ),
      body: SafeArea(
          child: loading ? LinearProgressIndicator() : Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Text("Email:"),
                TextField(
                  controller: emailController,
                ),
                Text("Password:"),
                TextField(
                  controller: passswordController,
                  obscureText: true,
                ),
                Divider(),
                ElevatedButton(onPressed: login, child: Text("Giriş Yap")),
                Divider(),
                ElevatedButton(
                    onPressed: () => Navigator.of(context).pushNamed("/register"), 
                    child: Text("Hesap Oluşturunuz"))
            ],
          ),
        ),
      ),
    );
  }
}