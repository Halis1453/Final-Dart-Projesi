import 'package:flutter/material.dart';

import 'screens/home.dart';
import 'screens/loading.dart';
import 'screens/login.dart';
import 'screens/register.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      routes: {
        '/login':(context) => LoginScreen(),
        '/register':(context) => RegisterScreen(),
        '/home':(context) => HomeScreen(),
        '/loading':(context) => LoadingScreen(),
      },
      initialRoute: '/loading',
    );
  }
}